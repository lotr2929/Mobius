import express from 'express';
import fetch from 'node-fetch';
import { createClient } from '@supabase/supabase-js';
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static('.'));

// ── AI functions ─────────────────────────────────────────────────────────────

async function askGroq(messages) {
  const r = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': 'Bearer ' + process.env.GROQ_API_KEY,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ model: 'llama-3.3-70b-versatile', messages })
  });
  const data = await r.json();
  return data.choices[0].message.content;
}

async function askGemini(messages) {
  const key = process.env.GEMINI_API_KEY;
  if (!key) throw new Error('GEMINI_API_KEY is not set on the server.');
  const contents = messages.map(m => ({
    role: m.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: m.content }]
  }));
  const url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent?key=' + key;
  const r = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ contents })
  });
  const data = await r.json();
  if (data.error) throw new Error('Gemini API error: ' + data.error.message);
  if (!data.candidates || !data.candidates[0]) throw new Error('No candidates in Gemini response: ' + JSON.stringify(data));
  return data.candidates[0].content.parts[0].text;
}

async function askWebSearch(messages) {
  const tavilyKey = process.env.TAVILY_API_KEY;
  if (!tavilyKey) throw new Error('TAVILY_API_KEY is not set on the server.');
  const lastUserMsg = [...messages].reverse().find(m => m.role === 'user');
  const query = lastUserMsg ? lastUserMsg.content : '';
  const searchRes = await fetch('https://api.tavily.com/search', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ api_key: tavilyKey, query, max_results: 5, include_answer: false })
  });
  const searchData = await searchRes.json();
  if (searchData.error) throw new Error('Tavily error: ' + searchData.error);
  const context = searchData.results
    .map((r, i) => `[${i+1}] ${r.title}\n${r.content}\nSource: ${r.url}`)
    .join('\n\n');
  const augmentedMessages = messages.map((m, i) => {
    if (i === messages.length - 1 && m.role === 'user') {
      return {
        role: 'user',
        content: `Answer the following question using the web search results below. Be concise and cite sources where relevant.\n\nQuestion: ${m.content}\n\nSearch Results:\n${context}`
      };
    }
    return m;
  });
  return await askGroq(augmentedMessages);
}

async function saveConversation(userId, question, answer, model, topic) {
  await supabase.from('conversations').insert({ user_id: userId, question, answer, model, topic });
}

// ── Parser ────────────────────────────────────────────────────────────────────

function buildMobiusQuery(text, model, history) {
  return {
    ASK: model,
    INSTRUCTIONS: history || [],   // chat history as context
    QUERY: text,
    FILES: []
  };
}

// ── Routes ────────────────────────────────────────────────────────────────────

// Step 1: Parse only — return mobius_query for user review
app.post('/parse', (req, res) => {
  const { text, model, history } = req.body;
  const mobius_query = buildMobiusQuery(text, model, history);
  res.json({ mobius_query });
});

// Step 2: Execute — receive mobius_query and send to AI
app.post('/ask', async (req, res) => {
  const { mobius_query, userId, topic } = req.body;
  const { ASK, INSTRUCTIONS, QUERY, FILES } = mobius_query;

  try {
    const messages = [
      ...INSTRUCTIONS,
      { role: 'user', content: QUERY }
    ];

    let reply;
    let modelUsed = ASK;

    if (ASK === 'gemini') {
      reply = await askGemini(messages);
    } else if (ASK === 'websearch') {
      reply = await askWebSearch(messages);
      modelUsed = 'groq';
    } else {
      reply = await askGroq(messages);
    }

    if (userId) await saveConversation(userId, QUERY, reply, modelUsed, topic || 'general');
    res.json({ reply, modelUsed });
  } catch (err) {
    console.error('Error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

// Login route
app.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const { data } = await supabase
    .from('users')
    .select('id, username')
    .eq('username', username)
    .eq('password', password)
    .single();
  if (data) {
    res.json({ userId: data.id, username: data.username });
  } else {
    res.status(401).json({ error: 'Invalid credentials' });
  }
});

app.get('/login', (req, res) => {
  res.sendFile('login.html', { root: '.' });
});

app.listen(PORT, () => console.log('Server on ' + PORT));