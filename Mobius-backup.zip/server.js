import express from 'express';
import fetch from 'node-fetch';
import { createClient } from '@supabase/supabase-js';
import { google } from 'googleapis';
import { getDriveFiles, getTasks, getCalendarEvents, getEmails, getGoogleClient } from './google_api.js';

const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static('.'));

// ── AI functions ──────────────────────────────────────────────────────────────

async function askGroq(messages) {
  const r = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': 'Bearer ' + process.env.GROQ_API_KEY,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ model: 'llama-3.3-70b-versatile', messages })
  });
  const data = await r.json();
  return data.choices[0].message.content;
}

async function askGemini(messages) {
  const key = process.env.GEMINI_API_KEY;
  if (!key) throw new Error('GEMINI_API_KEY is not set on the server.');
  const contents = messages.map(m => ({
    role: m.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: m.content }]
  }));
  const url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent?key=' + key;
  const r = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ contents })
  });
  const data = await r.json();
  if (data.error) throw new Error('Gemini API error: ' + data.error.message);
  if (!data.candidates || !data.candidates[0]) throw new Error('No candidates in Gemini response: ' + JSON.stringify(data));
  return data.candidates[0].content.parts[0].text;
}

async function askWebSearch(messages) {
  const tavilyKey = process.env.TAVILY_API_KEY;
  if (!tavilyKey) throw new Error('TAVILY_API_KEY is not set on the server.');
  const lastUserMsg = [...messages].reverse().find(m => m.role === 'user');
  const query = lastUserMsg ? lastUserMsg.content : '';
  const searchRes = await fetch('https://api.tavily.com/search', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ api_key: tavilyKey, query, max_results: 5, include_answer: false })
  });
  const searchData = await searchRes.json();
  if (searchData.error) throw new Error('Tavily error: ' + searchData.error);
  const context = searchData.results
    .map((r, i) => `[${i+1}] ${r.title}\n${r.content}\nSource: ${r.url}`)
    .join('\n\n');
  const augmentedMessages = messages.map((m, i) => {
    if (i === messages.length - 1 && m.role === 'user') {
      return {
        role: 'user',
        content: `Answer the following question using the web search results below. Be concise and cite sources where relevant.\n\nQuestion: ${m.content}\n\nSearch Results:\n${context}`
      };
    }
    return m;
  });
  return await askGroq(augmentedMessages);
}

async function saveConversation(userId, question, answer, model, topic) {
  await supabase.from('conversations').insert({ user_id: userId, question, answer, model, topic });
}

// ── Google OAuth ──────────────────────────────────────────────────────────────

const oauth2Client = new google.auth.OAuth2(
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET,
  process.env.GOOGLE_REDIRECT_URI
);

const GOOGLE_SCOPES = [
  'https://www.googleapis.com/auth/drive',
  'https://www.googleapis.com/auth/gmail.modify',
  'https://www.googleapis.com/auth/calendar',
  'https://www.googleapis.com/auth/tasks'
];

app.get('/auth/google', (req, res) => {
  const userId = req.query.userId;
  const url = oauth2Client.generateAuthUrl({
    access_type: 'offline',
    scope: GOOGLE_SCOPES,
    prompt: 'consent',
    state: userId
  });
  res.redirect(url);
});

app.get('/auth/google/callback', async (req, res) => {
  const { code, state: userId } = req.query;
  try {
    const { tokens } = await oauth2Client.getToken(code);
    await supabase.from('google_tokens').upsert({
      user_id: userId,
      access_token: tokens.access_token,
      refresh_token: tokens.refresh_token,
      expiry_date: tokens.expiry_date
    }, { onConflict: 'user_id' });
    res.redirect('/?google=connected');
  } catch (err) {
    console.error('Google OAuth error:', err.message);
    res.redirect('/?google=error');
  }
});

app.get('/auth/google/status', async (req, res) => {
  const { userId } = req.query;
  const { data } = await supabase
    .from('google_tokens')
    .select('user_id')
    .eq('user_id', userId)
    .single();
  res.json({ connected: !!data });
});

// ── Parser ────────────────────────────────────────────────────────────────────

function buildMobiusQuery(text, model, history) {
  return {
    ASK: model,
    INSTRUCTIONS: history || [],
    QUERY: text,
    FILES: []
  };
}

// ── Routes ────────────────────────────────────────────────────────────────────

app.post('/parse', (req, res) => {
  const { text, model, history } = req.body;
  const mobius_query = buildMobiusQuery(text, model, history);

  const lower = text.toLowerCase();
  if (lower.includes('drive') || lower.includes('my files') || lower.includes('google drive')) {
    mobius_query.ASK = 'google_drive';
  } else if (lower.includes('task') || lower.includes('todo') || lower.includes('to-do')) {
    mobius_query.ASK = 'google_tasks';
  } else if (lower.includes('calendar') || lower.includes('schedule') || lower.includes('events')) {
    mobius_query.ASK = 'google_calendar';
  } else if (lower.includes('email') || lower.includes('gmail') || lower.includes('inbox')) {
    mobius_query.ASK = 'google_gmail';
  }

  res.json({ mobius_query });
});

app.post('/ask', async (req, res) => {
  const { mobius_query, userId, topic } = req.body;
  const { ASK, INSTRUCTIONS, QUERY } = mobius_query;

  try {
    const messages = [...INSTRUCTIONS, { role: 'user', content: QUERY }];
    let reply;
    let modelUsed = ASK;

    if (ASK === 'google_drive') {
      reply = await getDriveFiles(userId, QUERY);
    } else if (ASK === 'google_tasks') {
      reply = await getTasks(userId);
    } else if (ASK === 'google_calendar') {
      reply = await getCalendarEvents(userId);
    } else if (ASK === 'google_gmail') {
      reply = await getEmails(userId);
    } else if (ASK === 'gemini') {
      reply = await askGemini(messages);
    } else if (ASK === 'websearch') {
      reply = await askWebSearch(messages);
      modelUsed = 'groq';
    } else {
      reply = await askGroq(messages);
    }

    if (userId) await saveConversation(userId, QUERY, reply, modelUsed, topic || 'general');
    res.json({ reply, modelUsed });
  } catch (err) {
    console.error('Error:', err.message);
    res.status(500).json({ error: err.message });
  }
});

app.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const { data } = await supabase
    .from('users')
    .select('id, username')
    .eq('username', username)
    .eq('password', password)
    .single();
  if (data) {
    res.json({ userId: data.id, username: data.username });
  } else {
    res.status(401).json({ error: 'Invalid credentials' });
  }
});

app.get('/login', (req, res) => {
  res.sendFile('login.html', { root: '.' });
});

app.listen(PORT, () => console.log('Server on ' + PORT));
